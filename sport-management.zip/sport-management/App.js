import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { AuthProvider, useAuth } from './screens/AuthContext';
import Login from './screens/login';
import Signup from './screens/signup';
import App from './screens/dashboard';
import History from './screens/history';
import NewHistory from './screens/newSport';
import NewColor from './screens/newColor';

const Stack = createNativeStackNavigator();

const Root = () => {
    return (
        <AuthProvider>
            <NavigationContainer>
                <MainNavigator />
            </NavigationContainer>
        </AuthProvider>
    );
};

const MainNavigator = () => {
    const { isAuthenticated } = useAuth();

    return (
        <Stack.Navigator initialRouteName="Login">
            {isAuthenticated ? (
                <>
                    <Stack.Screen 
                        name="App" 
                        component={App} 
                        options={{ headerShown: false }} 
                    />
                    <Stack.Screen 
                        name="History" 
                        component={History}  
                        options={{ headerShown: false }} 
                    />
                    <Stack.Screen
                      name="NewHistory"
                      component={NewHistory}
                      options={{ headerShown: true }}
                    />
                    <Stack.Screen
                      name="NewColor"
                      component={NewColor}
                      options={{ headerShown: true }}
                    />
                </>
            ) : (
                <>
                    <Stack.Screen 
                        name="Login" 
                        component={Login} 
                        options={{ headerShown: false }} 
                    />
                    <Stack.Screen 
                        name="Signup" 
                        component={Signup} 
                        options={{ headerShown: false }} 
                    />
                </>
            )}
        </Stack.Navigator>
    );
};

export default Root;