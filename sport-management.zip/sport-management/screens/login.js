import React, { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, Alert } from "react-native";
import styles from "../styles/styles"; // Import styles
import { useAuth } from './AuthContext'; // Import Auth context

const Login = ({ navigation }) => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const { login } = useAuth(); // Use the login function from context

  const handleLogin = async () => {
    try {
      const response = await fetch('http://encsport.sportsontheweb.net/login.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`,
      });

      const data = await response.json();
     
      if (data.message === "Login successful") {
        await login(); // Update auth state
        navigation.navigate('App'); // Redirect to App screen
      } 
    } catch (error) {
      console.error('Error:', error); 
      Alert.alert("Error", "An unexpected error occurred. Please try again.");
    }
  };

  return (
    <View style={styles.container}>
    <Text style={styles.title}>Login into Your Account </Text>
      <TextInput
        style={styles.input}
        placeholder="Username or Email" 
        value={username}
        onChangeText={setUsername}
        placeholderTextColor="#888"
        autoCapitalize="none"
      />
      <TextInput
        style={styles.input}
        placeholder="Password"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
        placeholderTextColor="#888"
        autoCapitalize="none"
      />
      <TouchableOpacity style={styles.button} onPress={handleLogin}>
        <Text style={styles.buttonText}>Login</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => navigation.navigate('Signup')}>
        <Text style={styles.linkText}>Don't have an account? Sign Up</Text>
      </TouchableOpacity>
    </View>
  );
};

export default Login; // Make sure Login is exported