import React, { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, Alert } from "react-native";
import styles from "../styles/styles"; // Import styles
import { useAuth } from './AuthContext'; // Import Auth context

const NewHistory = ({ navigation }) => {
  const [title, setTitle] = useState("");
  const [color, setColors] = useState("");

  const { login } = useAuth(); // Ensure you get the login function from context

  const handleSaveData = async () => {
    try {
      const response = await fetch('http://encsport.sportsontheweb.net/history.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `title=${encodeURIComponent(title)}&color=${encodeURIComponent(color)}`,
      });

      const data = await response.json();

       Alert.alert(data.message);
    } catch (error) {
      Alert.alert("Error", "An unexpected error occurred. Please try again.");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>New Sport Event</Text>
      <TextInput
        style={styles.input}
        placeholder="Sport Title"
        value={title}
        onChangeText={setTitle}
        placeholderTextColor="#888"
        autoCapitalize="none"
      />
      <TextInput
        style={styles.input}
        placeholder="Number's of Color"
        value={color}
        onChangeText={setColors}
        placeholderTextColor="#888"
        keyboardType="numeric"
        autoCapitalize="none"
      />
      <TouchableOpacity style={styles.button} onPress={handleSaveData}>
        <Text style={styles.buttonText}>Save History</Text>
      </TouchableOpacity>
    </View>
  );
};

export default NewHistory; 