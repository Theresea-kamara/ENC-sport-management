import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, SafeAreaView, Platform, Dimensions, StatusBar, Alert } from 'react-native';
import { PieChart } from 'react-native-chart-kit'; 
import globalStyle from '../styles/dbStyles';
import Footer from './footer';

const App = ({ navigation }) => {
  const [totalSports, setTotalSports] = useState(0);
  const [spendingTrends, setSpendingTrends] = useState([]);
  const [totalSport, setTotalSport] = useState([]);
  const [color, setColor] = useState([]);
  const [colorData, setColorData] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
        // Fetch total sports data
        const sport = await fetch('http://encsport.sportsontheweb.net/fetch_total.php');
        const sportResponse = await sport.json();
        setTotalSports(sportResponse.total);

        // Fetch history data
        const historyRes = await fetch('http://encsport.sportsontheweb.net/fetch_history.php');
        const historyData = await historyRes.json();

        if (Array.isArray(historyData)) {
          const titles = historyData.map(item => item.title);
          const colors = historyData.map(item => item.color);
          setTotalSport(titles);
          setColor(colors);
        } else {
          Alert.alert('Error', `Unexpected history data format: ${JSON.stringify(historyData)}`);
        }

        // Fetch color data
        const colorRes = await fetch('http://encsport.sportsontheweb.net/fetch_color.php');
        const colorJson = await colorRes.json();

        if (Array.isArray(colorJson)) {
          setColorData(colorJson);

          // Calculate the total points
          const totalPoints = colorJson.reduce((acc, item) => acc + item.point, 0);

          // Prepare the data for PieChart, calculating percentage
          const pieChartData = colorJson.map(item => ({
            name: item.color,  // This will be the label for the slice
            population: totalPoints > 0 ? (item.point / totalPoints) * 100 : 0,  // Calculate percentage
            color: item.color,  // You can also define the color if needed
            legendFontColor: "#7F7F7F",
            legendFontSize: 15
          }));
          
          setSpendingTrends(pieChartData);
        } else {
          Alert.alert('Error', `Unexpected color data format: ${JSON.stringify(colorJson)}`);
        }

    } catch (error) {
      Alert.alert('Error', `Error fetching data: ${error.message}`);
    }
  };

  return (
    <SafeAreaView style={globalStyle.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#f6f6f6" />
      <ScrollView contentContainerStyle={Platform.OS === 'android' ? globalStyle.andriodStyle : {}} style={globalStyle.paddingScrollView}>
        <View style={globalStyle.displayCol}> 
          <Text style={globalStyle.title}>Dashboard</Text>
        </View>
        
        <View style={globalStyle.textTitleView}>
          <Text style={globalStyle.textTitle}>Sport's Overview</Text>
          <View style={globalStyle.overView}>
            <Text style={globalStyle.textTitleSmall}>Total House's</Text>
            <Text style={globalStyle.currency}>{totalSports}</Text>
          </View>
          <Text style={globalStyle.textTitleSmall}>House per Category</Text>
          <PieChart
            data={spendingTrends}  // Using spendingTrends for the PieChart data
            width={Platform.OS === 'android' ? Dimensions.get('window').width - 20 : Dimensions.get('window').width}
            height={220}
            chartConfig={{
              backgroundColor: '#fff',
              backgroundGradientFrom: '#f6f6f6',
              backgroundGradientTo: '#f6f6f6',
              color: (opacity = 1) => `rgba(0, 122, 255, ${opacity})`,
              labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
              style: {
                borderRadius: 16,
              },
            }}
            accessor="population"  // This should match the data field used
            backgroundColor="#fff"
            paddingLeft="15"
            paddingRight="15"
            style={globalStyle.chart}
          />
        </View>
        
        <View style={globalStyle.textTitleView}>
          <View style={globalStyle.displayFlex}>
            <Text style={globalStyle.textTitleSmall}>Sport's</Text>
            <Text style={globalStyle.textTitleSmall}>House's</Text>
          </View>
          {totalSport.map((sport, index) => (
            <View key={index} style={globalStyle.displayFlex}>
              <Text style={globalStyle.displayText}>{sport}</Text>
              <Text style={globalStyle.displayText}>{color[index]}</Text> 
            </View>
          ))}
        </View>

        {/* Color and Points Section */}
        <View style={globalStyle.textTitleView}>
          <View style={globalStyle.displayFlex}>
            <Text style={globalStyle.textTitleSmall}>Color</Text>
            <Text style={globalStyle.textTitleSmall}>Point's</Text>
          </View>
          {colorData.map((item, index) => (
            <View key={index} style={globalStyle.displayFlex}>
              <Text style={globalStyle.displayText}>{item.color}</Text>
              <Text style={globalStyle.displayText}>{item.point}</Text>
            </View>
          ))}
        </View>
      </ScrollView>
      <Footer navigation={navigation} />
    </SafeAreaView>
  );
};

export default App;
