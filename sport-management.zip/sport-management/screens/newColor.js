import React, { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, Alert } from "react-native";
import styles from "../styles/styles"; // Import styles
import { useAuth } from './AuthContext'; // Import Auth context

const NewColor = ({ navigation }) => {
  const [title, setTitle] = useState("");
  const [house, setHouse] = useState("");
  const [point, setPoint] = useState("");
  const { login } = useAuth(); // Ensure you get the login function from context

  const handleSaveData = async () => {
    try {
      const response = await fetch('http://encsport.sportsontheweb.net/color.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `title=${encodeURIComponent(title)}&house=${encodeURIComponent(house)}&point=${encodeURIComponent(point)}`,
      });


      const data = await response.json();
      Alert.alert(data.message);
      
    } catch (error) {
      Alert.alert("Error", "An unexpected error occurred. Please try again.");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>New Color</Text>
      <TextInput
        style={styles.input}
        placeholder="Sport title"
        value={title}
        onChangeText={setTitle}
        placeholderTextColor="#888"
        autoCapitalize="none"
      />
      <TextInput
        style={styles.input}
        placeholder="Color Name"
        value={house}
        onChangeText={setHouse}
        placeholderTextColor="#888"
        keyboardType="numeric"
        autoCapitalize="none"
      />
      <TextInput
        style={styles.input}
        placeholder="Color Point"
        value={point}
        onChangeText={setPoint}
        placeholderTextColor="#888"
        keyboardType="numeric"
        autoCapitalize="none"
      />
      <TouchableOpacity style={styles.button} onPress={handleSaveData}>
        <Text style={styles.buttonText}>Save Data</Text>
      </TouchableOpacity>
    </View>
  );
};

export default NewColor; // Ensure NewAsset is exported