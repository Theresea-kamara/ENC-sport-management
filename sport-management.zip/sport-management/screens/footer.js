// components/Footer.js
import React from 'react';
import { View, TouchableOpacity, Text, Platform } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome'; 
import globalStyle from '../styles/dbStyles'; // Adjust the import path as necessary

const Footer = ({ navigation }) => {
  return (
    <View style={[
      globalStyle.displayFlexFooter, 
      Platform.OS === 'android' ? globalStyle.andriodPadding : {}
    ]}>
      <TouchableOpacity style={globalStyle.footerBox} onPress={() => navigation.navigate('App')}>
        <Icon name="dashboard" size={20} color="#000" />
        <Text style={globalStyle.footerBoxText}>Board</Text>
      </TouchableOpacity>
      <TouchableOpacity style={globalStyle.footerBox} onPress={() => navigation.navigate('History')}>
        <Icon name="history" size={20} color="#000" />
        <Text style={globalStyle.footerBoxText}>History</Text>
      </TouchableOpacity>
      <TouchableOpacity style={globalStyle.footerBox} onPress={() => navigation.navigate('NewHistory')}>
        <Icon name="plus" size={20} color="#000" />
        <Text style={globalStyle.footerBoxText}>New Sport's</Text>
      </TouchableOpacity>
       <TouchableOpacity style={globalStyle.footerBox} onPress={() => navigation.navigate('NewColor')}>
        <Icon name="plus" size={20} color="#000" />
        <Text style={globalStyle.footerBoxText}>New Color's</Text>
      </TouchableOpacity>
    </View>
  );
};

export default Footer;