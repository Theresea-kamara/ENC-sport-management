import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, SafeAreaView, Platform, StatusBar, Alert } from 'react-native';
import styles from '../styles/dbStyles';
import globalStyle from '../styles/dbStyles';
import Footer from './footer';

const History = ({ navigation }) => {
  const [totalSport, setTotalSport] = useState([]);
  const [color, setColor] = useState([]);
  const [colorData, setColorData] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      // Fetch history
      const historyRes = await fetch('http://encsport.sportsontheweb.net/fetch_history.php');
      const historyData = await historyRes.json();

      if (Array.isArray(historyData)) {
        const titles = historyData.map(item => item.title);
        const colors = historyData.map(item => item.color);
        setTotalSport(titles);
        setColor(colors);
        
        
      } else {
        Alert.alert('Error', `Unexpected history data format: ${JSON.stringify(historyData)}`);
      }

      // Fetch color data
      const colorRes = await fetch('http://encsport.sportsontheweb.net/fetch_color.php');
      const colorJson = await colorRes.json();

      if (Array.isArray(colorJson)) {
        setColorData(colorJson);
        
      } else {
        Alert.alert('Error', `Unexpected color data format: ${JSON.stringify(colorJson)}`);
      }

    } catch (error) {
      Alert.alert('Error', `Error fetching data: ${error.message}`);
    }
  };

  return (
    <SafeAreaView style={globalStyle.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#f6f6f6" />
      <ScrollView contentContainerStyle={Platform.OS === 'android' ? styles.andriodStyle : {}} style={globalStyle.paddingScrollView}>
        
        <View style={globalStyle.displayCol}> 
          <Text style={globalStyle.title}>History</Text>
        </View>

        {/* Sport and House Section */}
        <View style={globalStyle.textTitleView}>
          <View style={globalStyle.displayFlex}>
            <Text style={globalStyle.textTitleSmall}>Sport's</Text>
            <Text style={globalStyle.textTitleSmall}>House's</Text>
          </View>
          {totalSport.map((sport, index) => (
            <View key={index} style={globalStyle.displayFlex}>
              <Text style={globalStyle.displayText}>{sport}</Text>
              <Text style={globalStyle.displayText}>{color[index]}</Text> 
            </View>
          ))}
        </View>

        {/* Color and Points Section */}
        <View style={globalStyle.textTitleView}>
          <View style={globalStyle.displayFlex}>
            <Text style={globalStyle.textTitleSmall}>Color</Text>
            <Text style={globalStyle.textTitleSmall}>Point's</Text>
          </View>
          {colorData.map((item, index) => (
            <View key={index} style={globalStyle.displayFlex}>
              <Text style={globalStyle.displayText}>{item.color}</Text>
              <Text style={globalStyle.displayText}>{item.point}</Text>
            </View>
          ))}
        </View>
      
      </ScrollView>
      <Footer navigation={navigation} />
    </SafeAreaView>
  );
};

export default History;
